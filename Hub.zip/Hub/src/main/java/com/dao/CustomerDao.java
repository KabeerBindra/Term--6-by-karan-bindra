package com.dao;



import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.model.Customer;


public interface CustomerDao {

    void addCustomer (Customer customer);

    Customer getCustomerById (int customerId);

    List<Customer> getAllCustomers();
	/*
	 * Customer getCustomerByUsername (String username);
	 */

	UserDetails loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException;

}
